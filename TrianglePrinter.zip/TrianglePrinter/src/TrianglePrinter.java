import java.util.Scanner;

public class TrianglePrinter {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        while (true) {
            System.out.print("Enter the number of lines (or 'q' to quit): ");
            String input = scanner.nextLine();

            if (input.equals("q")) {
                break;
            }

            int lines = Integer.parseInt(input);
            if (lines < 1 || lines > 50) {
                System.out.println("Please enter a number between 1 and 50.");
                continue;
            }

            // Loop for each line of the triangle
            for (int i = 1; i <= lines; i++) {
                // Print leading spaces for triangle formatting
                for (int j = 0; j < lines - i; j++) {
                    System.out.print("  ");
                }

                // Print numbers descending from i to 1
                for (int j = i; j >= 1; j--) {
                    System.out.print(j + " ");
                }

                // Print numbers ascending from 2 to i
                for (int j = 2; j <= i; j++) {
                    System.out.print(j + " ");
                }

                System.out.println();
            }
        }

        scanner.close();
    }
}
